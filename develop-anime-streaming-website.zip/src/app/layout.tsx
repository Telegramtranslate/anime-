import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope, Unbounded } from "next/font/google";
import Header from "@/components/Header";
import Link from "next/link";
import "./globals.css";

const manrope = Manrope({ subsets: ["latin", "cyrillic"], variable: "--font-manrope" });
const unbounded = Unbounded({ subsets: ["latin", "cyrillic"], variable: "--font-unbounded", weight: ["500", "700", "800"] });

export const metadata: Metadata = {
  title: { default: "ANIVERSE — смотреть аниме онлайн", template: "%s · ANIVERSE" },
  description: "Тысячи аниме-сериалов и фильмов в HD с лучшими озвучками. Онгоинги, топы, каталог и персональная коллекция.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${manrope.variable} ${unbounded.variable}`}>
      <body className="noise bg-ink font-sans text-white antialiased">
        <Header />
        <main className="relative z-10">{children}</main>
        <footer className="relative z-10 mt-24 border-t border-line">
          <div className="mx-auto flex max-w-[1500px] flex-col gap-6 px-5 py-10 text-sm text-white/40 md:flex-row md:items-center md:justify-between md:px-10">
            <div>
              <div className="font-display text-lg font-bold text-white">ANI<span className="grad-text">VERSE</span></div>
              <p className="mt-1">Видео предоставляется плеером Kodik. Данные — Shikimori.</p>
            </div>
            <nav className="flex gap-6">
              <Link href="/catalog" className="hover:text-white">Каталог</Link>
              <Link href="/catalog?status=ongoing" className="hover:text-white">Онгоинги</Link>
              <Link href="/my" className="hover:text-white">Моя коллекция</Link>
            </nav>
          </div>
        </footer>
      </body>
    </html>
  );
}
